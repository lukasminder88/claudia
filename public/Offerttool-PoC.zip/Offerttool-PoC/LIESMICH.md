# Offerttool – Offline-Paket

Erzeugt aus einem Kalktool (`.xlsx`) eine fertige Offerte (`.docx`).
Regelbasiert, ohne KI: gleiche Eingabe ergibt gleiche Ausgabe.

## Loslegen

**`Offerttool.html` doppelklicken.** Mehr ist nicht nötig.

Es wird nichts installiert, nichts gestartet und nichts übertragen. Die Seite
rechnet vollständig im Browser; weder das Kalktool noch die Offerte verlassen
diesen Rechner. Ein Netzwerkzugang wird nicht gebraucht.

## Bedienung

1. Kalktool in das Feld ziehen (oder klicken und auswählen).
   Bei mehreren Standorten alle Kalktools wählen und die Reihenfolge mit den
   Pfeilen setzen – **die Reihenfolge ist die Reihenfolge der Standorte im
   Dokument.**
2. Die CRM-Felder sind freiwillig. Leer gelassene Felder erzeugen keine leere
   Zeile im Dokument. Fehlt die Offertnummer, tritt die Verkaufschance an ihre
   Stelle.
3. **Werte prüfen** zeigt, was aus dem Kalktool gelesen wird, ohne ein Dokument
   zu erzeugen. **Offerte erzeugen** liefert Offerte und Prüfprotokoll.

Zum Ausprobieren liegt unter `beispiel/` das Kalktool Birsfelden bei.

## Was Sie wissen sollten

**Seitenzahlen im Inhaltsverzeichnis** trägt Word beim Öffnen selbst ein – der
Browser kann sie nicht vorausberechnen. Das Verzeichnis ist vollständig und
richtig nummeriert; nur die Zahlen erscheinen erst beim ersten Öffnen in Word.
Deshalb meldet die Seite immer die Warnung `W321`.

**Abbrüche.** Stimmt etwas im Kalktool nicht, bricht der Generator mit einem
Fehlercode ab und erzeugt **keine** Datei – nie eine halbe Offerte. Der Code
steht im Klartext in der Seite, zum Beispiel `E401` für eine unbekannte
Finanzierungsart.

**Warnungen** stehen in der Seite und im Prüfprotokoll, nie im Dokument selbst.

**Marge, CIF und Kalkulationsfaktoren** aus dem Kalktool werden weder gelesen
noch ausgegeben. Vor dem Herunterladen prüft die Seite den fertigen Text noch
einmal gegen diese Werte.

## Browser

Chrome oder Edge ab Version 103, Firefox ab 113, Safari ab 16.4.
Ältere Browser meldet die Seite beim Öffnen.

## Grenzen dieses Standes

- Das Kalktool muss die Version **Q4 2025** sein. Andere Versionen brauchen
  eine angepasste Zuordnung der Zellen.
- Die Hardwaretabelle zeigt keine Artikelnummern und keine Zeilenpreise: das
  Kalktool führt diese Spalten nicht. Die Stückzahl ist fix 1 und wird gegen
  die Summe der Listenpreise plausibilisiert.
